package escritorio.ana.pOO_2025_1C.tPObligatoria.nro1.relacionesEntreClases.entidades.herencia;

public class AutoClasico extends Vehiculo {// Clase Hija de Vehiculo, hereda todos sus atributos.
    // Esta clase llama al constructor de la clase padre (Vehiculo) con la palabra super()

    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

    public AutoClasico(String marca, String modelo, String color, Double precio) {
        super(marca, modelo, color, precio);
    }

    public AutoClasico(String marca, String modelo, String color, Radio radio) {
        super(marca, modelo, color, radio);
    }

    public AutoClasico(String marca, String modelo, String color, Radio radio, Double precio) {
        super(marca, modelo, color, radio, precio);
    }

    @Override // sobreescritura del metodo heredado mostrarCategoriaVehiculo()
    public void mostrarCategoriaVehiculo() {
        System.out.println("Es un auto clasico");
    }

    @Override // sobre Escritura del toString
    public String toString() {
        return "Auto Clasico{" + super.toString() + "}";
    }
}
