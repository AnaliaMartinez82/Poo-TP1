package escritorio.ana.pOO_2025_1C.tPObligatoria.nro1.relacionesEntreClases.entidades.herencia;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@AllArgsConstructor
@ToString(exclude = "vehiculo")
public class Radio {
    // atributos
    private String marca;
    private int potencia;
    private Vehiculo vehiculo;// de esta forma se puede vincular la radio al vehiculo que pertenece (agregación)

    // Constructor
    public Radio(String marca, int potencia) {
        // Condicional if: Se ejecutará el bloque dentro del if, solo si todas las condiciones son verdaderas.
        if (marca != null && !marca.isBlank() && potencia > 0){
        this.marca = marca;
        this.potencia = potencia;
        this.vehiculo = null;// se puede crear la radio al principio, sin pertenecer algun vehiculo 
        }else{
            System.out.println("para crear una radio debe poseer marca y potencia > a o");
            // throw new IllegalArgumentException("para crear una radio debe poseer marca y potencia > 0");
        }
    }
}
