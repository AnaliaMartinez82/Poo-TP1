package escritorio.ana.pOO_2025_1C.tPObligatoria.nro1.relacionesEntreClases.tests;



import escritorio.ana.pOO_2025_1C.tPObligatoria.nro1.relacionesEntreClases.entidades.herencia.AutoClasico;
import escritorio.ana.pOO_2025_1C.tPObligatoria.nro1.relacionesEntreClases.entidades.herencia.AutoNuevo;
import escritorio.ana.pOO_2025_1C.tPObligatoria.nro1.relacionesEntreClases.entidades.herencia.Colectivo;
import escritorio.ana.pOO_2025_1C.tPObligatoria.nro1.relacionesEntreClases.entidades.herencia.Radio;

public class TestClases {
    public static void main(String[] args) {
        System.out.println("** Test de La clase Radio **");
        System.out.println();

		Radio radio1 = new Radio("pionner", 20);
		System.out.println(radio1);

		Radio radio2 = new Radio("sony", 40);
		System.out.println(radio2);


		Radio radio3 = new Radio("JBL", 30);
		System.out.println(radio3);

		Radio radio4 = new Radio("Panasonic", 10);
		System.out.println(radio4);

		Radio radio5 = new Radio("Panasonic", 20);
		System.out.println(radio5);

		Radio radio6 = new Radio("Panasonic", 30);
		System.out.println(radio6);

		Radio radio7 = new Radio("pionner", 40);
		System.out.println(radio7);

		Radio radio8 = new Radio("pionner", 60);
		System.out.println(radio8);

		Radio radio9 = new Radio("pionner", 30);
		System.out.println(radio9);

		Radio radio10 = new Radio("sony", 30);
		System.out.println(radio10);

		Radio radio11 = new Radio("sony", 60);
		System.out.println(radio11);

		Radio radio12 = new Radio("JBL", 20);
		System.out.println(radio12);


		Radio radio13 = new Radio(null, 10);
		System.out.println(radio13);

		Radio radio14 = new Radio("", 5);
		System.out.println(radio14);

		Radio radio15 = new Radio("aiwa", 0);
		System.out.println(radio15);


        System.out.println();
        System.out.println("Clase Radio funcionando correctamente");
		System.out.println("---------------------------------------------");
		System.out.println();

        System.out.println("** Test de la clase Colectivo **");
		System.out.println();

		Colectivo colectivo1 = new Colectivo("Mercedes Benz", "Minibus", "Rojo");
		System.out.println(colectivo1);

		Colectivo colectivo2 = new Colectivo("Mercedes Benz", "Interurbano", "Blanco", 100000.5 );
		System.out.println(colectivo2);

		Colectivo colectivo3 = new Colectivo("Scania", "Larga distancia", "azul", radio1);
		System.out.println(colectivo3);

		Colectivo colectivo4 = new Colectivo("Scania", "Urbano", "amarillo", radio2);
		System.out.println(colectivo4);

		System.out.println();
		System.out.println("Clase Colectivo funcionando correctamente");
		System.out.println("---------------------------------------------");
		System.out.println();

        System.out.println("** Test de la clase AutoClasico **");
		System.out.println();

		AutoClasico autoClasico1 = new AutoClasico("peugeot", "308", "azul");
		System.out.println(autoClasico1);

		AutoClasico autoClasico2 = new AutoClasico("fiat", "palio", "gris", radio3);
		System.out.println(autoClasico2);

		AutoClasico autoClasico3 = new AutoClasico("renault", "sandero", "negro", 15000.5);
		System.out.println(autoClasico3);

		AutoClasico autoClasico4 = new AutoClasico("citroen", "picasso", "bordó", radio4, 18000.5);
		System.out.println(autoClasico4);

		autoClasico1.agregarRadio(radio3);
		System.out.println(autoClasico1);

		autoClasico1.cambiarRadio(radio3);
		System.out.println(autoClasico1);
		System.out.println(autoClasico2);


		System.out.println();
		System.out.println("Clase AutoClasico funcionando correctamente");
		System.out.println("---------------------------------------------");
		System.out.println();

        System.out.println("** Test de la clase AutoNuevo **");
		System.out.println();

		AutoNuevo autoNuevo1 = new AutoNuevo("EQE SUV", "Mercedez Benz", "azul", radio5);
		System.out.println(autoNuevo1);

		AutoNuevo autoNuevo2 = new AutoNuevo("F80", "Ferrari", null, radio6, 80000.9);
		System.out.println(autoNuevo2);

		AutoNuevo autoNuevo3 = new AutoNuevo("GLC Coupe", "Mercedes Benz", "negro", radio7, 78000.5);
		System.out.println(autoNuevo3);

		AutoNuevo autoNuevo4 = new AutoNuevo("SF90 Stradale", "Ferrari", "rojo", radio8);
		System.out.println(autoNuevo4);

		// AutoNuevo autoNuevo5 = new AutoNuevo("S50", "audi", "azul",null);
		// System.out.println(autoNuevo5);

		AutoNuevo autoNuevo5 = new AutoNuevo("S50", "audi", "azul",radio11);
		System.out.println(autoNuevo5);
        
		autoNuevo5.agregarRadio(radio9);
		System.out.println(autoNuevo5);

		autoNuevo5.cambiarRadio(radio15);
		System.out.println(autoNuevo5);

		autoNuevo5.cambiarRadio(radio8);
		System.out.println(autoNuevo5);
		System.out.println(autoNuevo4);

    }
}
