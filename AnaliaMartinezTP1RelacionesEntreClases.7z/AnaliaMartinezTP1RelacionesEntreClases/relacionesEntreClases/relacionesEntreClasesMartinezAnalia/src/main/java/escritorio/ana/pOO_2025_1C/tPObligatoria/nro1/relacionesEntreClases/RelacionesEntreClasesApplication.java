package escritorio.ana.pOO_2025_1C.tPObligatoria.nro1.relacionesEntreClases;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelacionesEntreClasesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RelacionesEntreClasesApplication.class, args);
	}

}
