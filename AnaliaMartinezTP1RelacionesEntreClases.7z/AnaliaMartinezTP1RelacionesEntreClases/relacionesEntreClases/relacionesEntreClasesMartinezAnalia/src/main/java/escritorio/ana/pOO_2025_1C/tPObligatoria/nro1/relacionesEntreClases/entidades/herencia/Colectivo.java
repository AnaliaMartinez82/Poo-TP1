package escritorio.ana.pOO_2025_1C.tPObligatoria.nro1.relacionesEntreClases.entidades.herencia;

public final class Colectivo extends Vehiculo {// final para que la clase no tenga clases hijas

      // Clase Hija de Vehiculo, hereda todos sus atributos.
      // Esta clase llama al constructor de la clase padre (Vehiculo) con la palabra
      // super()

      public Colectivo(String marca, String modelo, String color, Radio radio, Double precio) {
            super(marca, modelo, color, precio);
            super.agregarRadio(radio);
      }

      public Colectivo(String marca, String modelo, String color, Radio radio) {
            super(marca, modelo, color);
            super.agregarRadio(radio);
      }

      public Colectivo(String marca, String modelo, String color, Double precio) {
            super(marca, modelo, color, precio);
      }

      public Colectivo(String marca, String modelo, String color) {
            super(marca, modelo, color);
      }

      // sobre Escritura del metodo
      @Override
      public void mostrarCategoriaVehiculo() {
            System.out.println("Es un colectivo");
      }

      // sobre Escritura del toString
      @Override
      public String toString() {
            return "Colectivo{" + super.toString() + "}";// super.toString(), estás diciendo: "Llama al método
                                                         // toString() que está definido en la clase padre"
      }

}
