package escritorio.ana.pOO_2025_1C.tPObligatoria.nro1.relacionesEntreClases.entidades.herencia;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class Vehiculo {// Clase abstracta no se pueden crear objetos, de esta clase. Es una SuperClase

    // atributos con modificador de acceso.
    // private: acceso restringido, solo accesible desde la misma clase o subclases.
    private String marca;
    private String modelo;
    private String color;
    private Double precio;
    @Setter(AccessLevel.NONE) // No se generará ningun metodo setter para el campo que continua: radio
    private Radio radio;

    // Constructores con algunos atributos o completo
    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    public Vehiculo(String marca, String modelo, String color, Radio radio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.radio = radio;
    }

    public Vehiculo(String marca, String modelo, String color, Double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }

    public Vehiculo(String marca, String modelo, String color, Radio radio, Double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.radio = radio;
        this.precio = precio;
    }

    /**
     * Metodo para evaluar que la radio fue creada incorrectamente
     * 
     * @param nuevaRadio
     */
    public void setRadio(Radio nuevaRadio) {
        if (nuevaRadio == null || !nuevaRadio.radioValida()) {
            System.out.println("La radio fue creada incorrectamente, no se puede usar");
        }
    }

    /**
     * Este metodo agrega una radio,si el vehiculo no posee una previamente, de lo
     * contrario evalua si la radio esta en otro vehiculo, e imprime que no se puede
     * usar y que debera llamar al metodo cambiarRadio().
     * 
     * @param nuevaRadio
     */
    public void agregarRadio(Radio nuevaRadio) {

        if (nuevaRadio != null) {
            if (nuevaRadio.getVehiculo() != null && nuevaRadio.getVehiculo() != this) {
                // si la radio esta en otro vehiculo no se puede usar
                System.out.println(
                        "Esta radio ya está en otro vehículo,no se podria usar, antes deberia desvincularlo. llamar al metodo cambiarRadio()");
                cambiarRadio(nuevaRadio);
            } else {
                this.radio = nuevaRadio;
            }
        }
    }

    /**
     * Se utiliza para cambiar la radio de un vehiculo, primero se desvincula la
     * radio existente del vehiculo y luego se agrega la nueva radio.
     * 
     * @param nuevaRadio
     */
    public void cambiarRadio(Radio nuevaRadio) {
        if (this.radio != null && this.radio != nuevaRadio) {
            this.radio.setVehiculo(null);// si el vehiculo ya tiene una radio, la desasocio/desvinculo
            this.radio = nuevaRadio;// asigno la nueva radio
            nuevaRadio.setVehiculo(this);// asigna dueño a la radio, pertenencia a un vehiculo.
            System.out.println("Radio desvinculada y asignada correctamente");
        }
    }

    // metodo abstracto, solo firma. Permite escritura en las subclases
    public abstract void mostrarCategoriaVehiculo();

    @Override // To String extiende de Clase Object
    public String toString() {
        return "Vehiculo{" +
                "marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", color='" + color + '\'' +
                ", precio=" + precio +
                ", radio=" + radio +
                '}';
    }
}
