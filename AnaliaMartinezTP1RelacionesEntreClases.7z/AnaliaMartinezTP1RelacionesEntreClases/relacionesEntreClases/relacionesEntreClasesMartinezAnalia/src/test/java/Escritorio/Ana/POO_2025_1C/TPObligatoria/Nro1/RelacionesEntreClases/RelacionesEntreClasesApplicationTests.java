package Escritorio.Ana.POO_2025_1C.TPObligatoria.Nro1.RelacionesEntreClases;


import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class RelacionesEntreClasesApplicationTests {

	public static void main(String[] args) {
		
	}
}
