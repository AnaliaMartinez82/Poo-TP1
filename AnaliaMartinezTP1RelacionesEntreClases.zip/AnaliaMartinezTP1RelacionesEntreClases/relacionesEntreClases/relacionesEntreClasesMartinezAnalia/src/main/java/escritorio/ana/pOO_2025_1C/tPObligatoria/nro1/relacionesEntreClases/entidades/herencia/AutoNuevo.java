package escritorio.ana.pOO_2025_1C.tPObligatoria.nro1.relacionesEntreClases.entidades.herencia;

public class AutoNuevo extends Vehiculo {// Los atributos son heredados de la super clase Vehiculo
    // El atributo radio es obligatorio al crear el AutoNuevo.
    // El atributo precio es opcional al crear el constructor.

    public AutoNuevo(String marca, String modelo, String color, Radio radio) {
        super(marca, modelo, color,radio);
       if (radio == null) { // Si alguien intenta crear un Auto nuevo sin radio(null),lanza error
          throw new IllegalArgumentException("Un AutoNuevo debe tener una radio al crearse.\n");
        }
    }

    public AutoNuevo(String marca, String modelo, String color, Radio radio, Double precio) {
        super(marca, modelo, color, radio, precio);
        if (radio == null) { // Si alguien intenta crear un Auto nuevo sin radio(null),lanza error
            throw new IllegalArgumentException("Un AutoNuevo debe tener una radio al crearse.\n");
        }
    }

    @Override // sobreescritura del metodo heredado mostrarCategoriaVehiculo()
    public void mostrarCategoriaVehiculo() {
        System.out.println("Es un auto nuevo");
    }

    @Override // sobre Escritura del toString
    public String toString() {
        return "Auto Nuevo{" + super.toString() + "}";
    }
}
