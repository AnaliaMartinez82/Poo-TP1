package escritorio.ana.pOO_2025_1C.tPObligatoria.nro1.relacionesEntreClases.entidades.herencia;

public final class Colectivo extends Vehiculo {// final: para que la clase no tenga clases hijas
      // Clase Hija de Vehículo, hereda todos sus atributos. Esta clase llama al constructor de la clase padre (Vehículo) con la palabra super()

      public Colectivo(String marca, String modelo, String color, Radio radio, Double precio) {
            super(marca, modelo, color, radio, precio);
      }

      public Colectivo(String marca, String modelo, String color, Radio radio) {
            super(marca, modelo, color,radio);
      }

      public Colectivo(String marca, String modelo, String color, Double precio) {
            super(marca, modelo, color, precio);
      }

      public Colectivo(String marca, String modelo, String color) {
            super(marca, modelo, color);
      }

      @Override // sobre Escritura del metodo
      public void mostrarCategoriaVehiculo() {
            System.out.println("Es un colectivo");
      }

      @Override // sobre Escritura del toString
      public String toString() {
            return "Colectivo{" + super.toString() + "}";// super.toString(), estás diciendo: "Llama al método toString() que está definido en la clase padre"
      }
}
