package escritorio.ana.pOO_2025_1C.tPObligatoria.nro1.relacionesEntreClases.entidades.herencia;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class Vehiculo {// Clase abstracta no se pueden crear objetos, de esta clase. Es una SuperClase
    // atributos con modificador de acceso. private: acceso restringido, solo
    // accesible desde la misma clase o subclases.
    private String marca;
    private String modelo;
    private String color;
    private Double precio;
    @Setter(AccessLevel.NONE) // No se generará ningun metodo setter para el campo que continua: radio
    private Radio radio;

    // Constructores con algunos atributos o completo
    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    public Vehiculo(String marca, String modelo, String color, Radio radio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.radio = radio;
    }

    public Vehiculo(String marca, String modelo, String color, Double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }

    public Vehiculo(String marca, String modelo, String color, Radio radio, Double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.radio = radio;
        this.precio = precio;
    }

    /**
     * Este método agrega una radio, previamente evalua que la radio no esté
     * asociada a un vehiculo, o el vehiculo ya tenga una radio.
     * @param nuevaRadio
     */
    public void agregarRadio(Radio nuevaRadio) { 
        if (nuevaRadio.getVehiculo()!= null) {
            System.out.println("\n Esta radio ya está asignada a otro vehículo. Use cambiarRadio() si desea reemplazar.");
        } else if (this.radio != null) {
            System.out.println("\n Este vehículo ya tiene una radio. Use cambiarRadio() si desea reemplazar.");
        } else {
            this.radio = nuevaRadio;// Este vehículo (el que está ejecutando el código) ahora tiene como radio a nuevaRadio
            nuevaRadio.setVehiculo(this);// A la nueva radio, la vinculamos a su nuevo vehículo, doble vinculación
            System.out.println("\n Radio agregada correctamente.");
        }
    }

     /**
     * Se utiliza para cambiar la radio de un vehiculo,
     * primero se desvincula la radio existente del vehiculo
     * segundo desvincula el vehiculo de la radio
     * por ultimo agrega la nueva radio, se lo vincula al vehiculo y viceversa.
     * @param nuevaRadio
     */
    public void cambiarRadio(Radio nuevaRadio){
        if (this.radio !=null | nuevaRadio.getVehiculo() != null ) {
             nuevaRadio.setVehiculo(null);//limpia la nuevaRadio, la desvinculo si estaba asignada en un auto
             this.radio.setVehiculo(null); // desvincula la radio del anterior vehiculo, ahora el vehiculo (de esta radio) es null
             this.radio = null;//la radio (de este vehiculo=this) ahora es null, se produce una doble desvinculacion
             this.radio = nuevaRadio;// Este vehículo (el que está ejecutando el código) ahora tiene como radio a nuevaRadio
             nuevaRadio.setVehiculo(this);// A la nueva radio, la vinculamos a su nuevo vehículo, doble vinculación
             System.out.println("\n Radio reemplazada correctamente.");
        }else{
            System.out.println("\n El vehículo no posee radio, agrege una");
        }
    }

    // metodo abstracto, solo firma. Permite escritura en las subclases
    public abstract void mostrarCategoriaVehiculo();

    @Override // To String extiende de Clase Object
    public String toString() {
        return "Vehiculo{" +
                "marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", color='" + color + '\'' +
                ", precio=" + precio +
                ", radio=" + radio +
                '}';
    }
}
